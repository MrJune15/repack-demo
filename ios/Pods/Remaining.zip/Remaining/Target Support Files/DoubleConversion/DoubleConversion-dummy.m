#import <Foundation/Foundation.h>
@interface PodsDummy_DoubleConversion : NSObject
@end
@implementation PodsDummy_DoubleConversion
@end
