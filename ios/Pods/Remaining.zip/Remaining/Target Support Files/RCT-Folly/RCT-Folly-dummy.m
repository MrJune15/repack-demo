#import <Foundation/Foundation.h>
@interface PodsDummy_RCT_Folly : NSObject
@end
@implementation PodsDummy_RCT_Folly
@end
