#import <Foundation/Foundation.h>
@interface PodsDummy_React_Codegen : NSObject
@end
@implementation PodsDummy_React_Codegen
@end
