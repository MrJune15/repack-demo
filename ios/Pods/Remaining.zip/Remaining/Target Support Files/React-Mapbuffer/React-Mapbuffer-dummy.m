#import <Foundation/Foundation.h>
@interface PodsDummy_React_Mapbuffer : NSObject
@end
@implementation PodsDummy_React_Mapbuffer
@end
