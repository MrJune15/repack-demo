#import <Foundation/Foundation.h>
@interface PodsDummy_React_RCTAppDelegate : NSObject
@end
@implementation PodsDummy_React_RCTAppDelegate
@end
