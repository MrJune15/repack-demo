#import <Foundation/Foundation.h>
@interface PodsDummy_React_RCTText : NSObject
@end
@implementation PodsDummy_React_RCTText
@end
