#import <Foundation/Foundation.h>
@interface PodsDummy_React_hermes : NSObject
@end
@implementation PodsDummy_React_hermes
@end
