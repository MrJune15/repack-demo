#import <Foundation/Foundation.h>
@interface PodsDummy_React_jserrorhandler : NSObject
@end
@implementation PodsDummy_React_jserrorhandler
@end
