#import <Foundation/Foundation.h>
@interface PodsDummy_React_nativeconfig : NSObject
@end
@implementation PodsDummy_React_nativeconfig
@end
