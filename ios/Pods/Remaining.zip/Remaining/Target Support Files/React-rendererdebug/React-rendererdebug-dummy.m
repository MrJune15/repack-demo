#import <Foundation/Foundation.h>
@interface PodsDummy_React_rendererdebug : NSObject
@end
@implementation PodsDummy_React_rendererdebug
@end
