#import <Foundation/Foundation.h>
@interface PodsDummy_SocketRocket : NSObject
@end
@implementation PodsDummy_SocketRocket
@end
