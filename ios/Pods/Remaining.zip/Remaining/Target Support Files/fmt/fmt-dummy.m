#import <Foundation/Foundation.h>
@interface PodsDummy_fmt : NSObject
@end
@implementation PodsDummy_fmt
@end
